const corpo = document.getElementsByTagName("body")[0];

corpo.addEventListener('click', ()=>{
    window.location.href="/pagHome/home.html"
});