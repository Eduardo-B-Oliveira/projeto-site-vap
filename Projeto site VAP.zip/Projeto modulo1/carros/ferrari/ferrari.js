const transicaoPrOpcoes = document.querySelector("#linhaverde");

function troca(){
    window.location.href = "/pagHome/home.html"
}

transicaoPrOpcoes.addEventListener("click", troca);



document.getElementById("comprar").addEventListener('click', ()=>{

    window.location.href = "/login/login.html";

});