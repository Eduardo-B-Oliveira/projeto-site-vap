const op1 = document.querySelector("#listaopcao1");
const op2 = document.querySelector("#listaopcao2");
const op3 = document.querySelector("#listaopcao3");

function alert1(){
}

op1.addEventListener("click", alert1);

function alert2(){
    alert("voce cliclou na opção " + op2.textContent);
}

op2.addEventListener("click", alert2);

function alert3(){
    alert("voce cliclou na opção " + op3.textContent);
}

op3.addEventListener("click", alert3);




const transicaoPrOpcoes = document.querySelector("#linhaverde");

function troca(){
    window.location.href = "/pagHome/home.html"
}

transicaoPrOpcoes.addEventListener("click", troca);

listaopcao1.addEventListener('click', ()=>{window.location.href="/login/login.html"})