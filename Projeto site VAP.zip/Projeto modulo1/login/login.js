function irParaHome(){
    window.location.href = "/pagHome/home.html"
}

BTvisitante.addEventListener('click', irParaHome);
BTentrar.addEventListener('click', irParaHome);