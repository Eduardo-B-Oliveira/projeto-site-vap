const transicaoPrOpcoes = document.querySelector("#engrenagem");

function troca(){
    window.location.href = "/pagOpcoes/opcoes.html"
}

transicaoPrOpcoes.addEventListener("click", troca);



document.getElementById("divTresBarrinhas").addEventListener('click', ()=>{
    window.location.href = "/pagItens/itens.html"
});

//////////////////////////////////////////////////////////////////////////

const nadaAqui = document.getElementById("nadaAquiDiv");
nadaAqui.style.display = "none";

//////////////////////////////////////////////////////////////////////////
///////carros///////
const carros = [
    { marca: "Ferrari", modelo: "SF900 Spider", imagem: "/imagens/ferrari sf90 spider.jpg", link: "/carros/ferrari/ferrari.html" },
    { marca: "Porsche", modelo: "911 GT", imagem: "/imagens/porsche 911 gts.webp", link: "/carros/porsche/porsche.html" },
    { marca: "Lamborghini", modelo: "Huracán STO", imagem: "/imagens/lamborghini huracan STO.jpg", link: "/carros/lamborghini/lamborghini.html" },
    { marca: "Mercedes Benz", modelo: "Maybach Classe S", imagem: "/imagens/Mercedes Benz - Maybach Classe S.jpg", link: "/carros/mercedes/mercedes.html" }
];

const divTodosArtigos = document.getElementById("divTodosArtigos");

carros.map(carro => {
    const article = document.createElement("article");
    article.classList.add("article");
    article.id = `article-${carro.marca}`;

    const divCarro = document.createElement("div");
    divCarro.classList.add("carro");
    divCarro.textContent = carro.marca;

    const imagemCarro = document.createElement("img");
    imagemCarro.classList.add("imagensCarrosArticle");
    imagemCarro.src = carro.imagem;

    const tituloCarro = document.createElement("p");
    tituloCarro.classList.add("fonte18padrao");
    tituloCarro.textContent = carro.modelo;

    const detalhesCarro = document.createElement("p");
    detalhesCarro.classList.add("fonte14detalhes");
    detalhesCarro.style.color = "#AAAAAA";
    detalhesCarro.innerHTML = '<input type="checkbox" class="checkboxCarrinho"> Adicionar ao carrinho';

    imagemCarro.addEventListener("click", () => {
        window.location.href = carro.link;
    });

    article.appendChild(divCarro);
    article.appendChild(imagemCarro);
    article.appendChild(tituloCarro);
    article.appendChild(detalhesCarro);

    divTodosArtigos.appendChild(article);
});





///////barra de pesquisa///////

const barraPesquisa = document.getElementById("barraPesquisa");
const divChamaris = document.getElementById("divChamaris");

barraPesquisa.addEventListener("input", () => {
    const valor = barraPesquisa.value.toLowerCase();
    let conteudoVisivel = false;
    
    /////para o abencoado do chamaris desaparecer/////
    if (valor !== "") {
        divChamaris.style.display = "none";
    } else {
        divChamaris.style.display = "";
    }

    carros.map(carro => {
        const article = document.getElementById(`article-${carro.marca}`);
        const marca = carro.marca.toLowerCase();
        const modelo = carro.modelo.toLowerCase();

        if (marca.includes(valor) || modelo.includes(valor)) {
            article.style.display = "";
            conteudoVisivel = true;
        } else {
            article.style.display = "none";
        }
    });

    if (conteudoVisivel) {
        nadaAqui.style.display = "none";
    } else {
        nadaAqui.style.display = "";
    }

});





///////carrinho///////

let carrinho = [];

function contador() {
    const span = document.getElementById("contador");
    span.textContent = carrinho.length.toString();
}

const checagens = document.querySelectorAll('.checkboxCarrinho')
checagens.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            const carro = checkbox.parentElement.id;
            
            if (checkbox.checked) {
                carrinho.push(carro);
            } else {
                carrinho = carrinho.filter(carro => carro !== carro);
            }
            
            contador();
        });
    });
    
    document.getElementById("divCarrinho").addEventListener('click', () => {
        document.querySelectorAll('.checkboxCarrinho').forEach(checkbox => {
            checkbox.checked = false;
        });
        
        carrinho = [];
        contador();
    });